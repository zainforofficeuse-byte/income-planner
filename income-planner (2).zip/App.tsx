
import React, { useState, useMemo, useCallback, useEffect } from 'react';
import type { Entry, CurrencySymbols } from './types';

const currencySymbols: CurrencySymbols = {
    'USD': '$',
    'EUR': '€',
    'GBP': '£',
    'INR': '₹',
    'PKR': '₨',
    'AED': 'د.إ',
    'PHP': '₱',
};

const defaultIncomeCategories = ['Salary', 'Profit', 'Loan', 'Gift', 'Other'];
const defaultExpenseCategories = ['Repay Loan', 'Grocery', 'Rent', 'Transport', 'Entertainment', 'Other'];

// --- Helper Components (Defined outside main component to prevent re-creation) ---

interface SettingsModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSelectCurrency: (currency: string) => void;
    selectedCurrency: string;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, onSelectCurrency, selectedCurrency }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-end z-50" onClick={onClose}>
            <div className="bg-white dark:bg-gray-800 w-full max-w-md rounded-t-2xl p-6 animate-slide-up" onClick={(e) => e.stopPropagation()}>
                <h2 className="text-xl font-bold mb-4 text-gray-800 dark:text-gray-100">Select Currency</h2>
                <div className="space-y-2 max-h-[60vh] overflow-y-auto">
                    {Object.entries(currencySymbols).map(([code, symbol]) => (
                        <div
                            key={code}
                            onClick={() => onSelectCurrency(code)}
                            className="flex items-center justify-between p-3 rounded-lg cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        >
                            <div className="flex items-center">
                                <span className="text-2xl w-8 text-center text-gray-700 dark:text-gray-300">{symbol}</span>
                                <span className="ml-4 font-medium text-gray-700 dark:text-gray-300">{code}</span>
                            </div>
                            {selectedCurrency === code && (
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-500 dark:text-green-400" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                                </svg>
                            )}
                        </div>
                    ))}
                </div>
            </div>
            <style>{`
                @keyframes slide-up {
                    from { transform: translateY(100%); }
                    to { transform: translateY(0); }
                }
                .animate-slide-up { animation: slide-up 0.3s ease-out forwards; }
            `}</style>
        </div>
    );
};


interface HistoryItemProps {
  entry: Entry;
  currencySymbol: string;
}

const HistoryItem: React.FC<HistoryItemProps> = React.memo(({ entry, currencySymbol }) => {
  const isIncome = entry.isIncome;
  const sign = isIncome ? '+' : '-';
  const colorClass = isIncome ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400';
  const bgColorClass = isIncome ? 'bg-green-100 dark:bg-green-900/50' : 'bg-red-100 dark:bg-red-900/50';

  return (
    <div className="flex items-center py-3">
      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${bgColorClass} ${colorClass} font-bold text-lg`}>
        {sign}
      </div>
      <div className="ml-4 flex-grow">
        <p className="font-semibold text-gray-800 dark:text-gray-100">{entry.description}</p>
        <p className={`text-sm font-bold ${colorClass}`}>
          {currencySymbol} {entry.amount.toLocaleString()}
        </p>
      </div>
      <div className="text-right text-xs text-gray-500 dark:text-gray-400">
        <p>{entry.date}</p>
        <p>{entry.time}</p>
      </div>
    </div>
  );
});

// --- Main Application Component ---

const App: React.FC = () => {
    const [entries, setEntries] = useState<Entry[]>([]);
    const [amount, setAmount] = useState<string>('');
    const [description, setDescription] = useState<string>('');
    const [selectedCurrency, setSelectedCurrency] = useState<string>('USD');
    const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
    const [error, setError] = useState<string>('');
    
    const [theme, setTheme] = useState<'light' | 'dark'>(() => {
        if (typeof window === 'undefined') return 'light';
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark' || savedTheme === 'light') return savedTheme;
        return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    });

    useEffect(() => {
        const root = window.document.documentElement;
        if (theme === 'dark') {
            root.classList.add('dark');
        } else {
            root.classList.remove('dark');
        }
        localStorage.setItem('theme', theme);
    }, [theme]);

    const handleThemeToggle = () => {
        setTheme(prev => (prev === 'light' ? 'dark' : 'light'));
    };

    const totalBalance = useMemo(() => {
        return entries.reduce((sum, entry) => {
            return sum + (entry.isIncome ? entry.amount : -entry.amount);
        }, 0);
    }, [entries]);

    const suggestionList = useMemo(() => {
        const recentDescriptions = entries
            .slice(-10)
            .reverse()
            .map(e => e.description);
        const uniqueRecent = [...new Set(recentDescriptions)];
        const combined = [...defaultIncomeCategories, ...defaultExpenseCategories, ...uniqueRecent];
        return [...new Set(combined)];
    }, [entries]);
    
    const formatNumber = (input: string): string => {
        if (!input) return '';
        const digitsOnly = input.replace(/[^0-9]/g, '');
        if (!digitsOnly) return '';
        return parseInt(digitsOnly, 10).toLocaleString('en-US');
    };

    const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const formatted = formatNumber(e.target.value);
        setAmount(formatted);
    };

    const handleAddEntry = useCallback((isIncome: boolean) => {
        const cleanAmount = amount.replace(/,/g, '');
        const numericAmount = parseFloat(cleanAmount);

        if (isNaN(numericAmount) || numericAmount <= 0 || description.trim() === '') {
            setError('Please enter a valid amount and description.');
            setTimeout(() => setError(''), 3000);
            return;
        }

        const now = new Date();
        const newEntry: Entry = {
            id: Date.now(),
            amount: numericAmount,
            description: description.trim(),
            isIncome,
            date: now.toLocaleDateString('en-CA'), // YYYY-MM-DD
            time: now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }),
        };

        setEntries(prevEntries => [...prevEntries, newEntry]);
        setAmount('');
        setDescription('');
        setError('');
    }, [amount, description]);

    const handleSelectCurrency = (currencyCode: string) => {
        setSelectedCurrency(currencyCode);
        setIsSettingsOpen(false);
    };
    
    const currencySymbol = currencySymbols[selectedCurrency] ?? '$';

    return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 font-sans flex flex-col">
            <header className="bg-white dark:bg-gray-800/80 dark:backdrop-blur-sm dark:border-b dark:border-gray-700 shadow-sm sticky top-0 z-10">
                <div className="max-w-md mx-auto px-4 py-3 flex justify-between items-center">
                    <h1 className="text-xl font-bold text-gray-800 dark:text-gray-100">Income Planner</h1>
                    <div className="flex items-center gap-2">
                        <button onClick={handleThemeToggle} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors" aria-label="Toggle theme">
                           {theme === 'light' ? (
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-600 dark:text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                  <path strokeLinecap="round" strokeLinejoin="round" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                                </svg>
                           ) : (
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-600 dark:text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                                </svg>
                           )}
                        </button>
                        <button onClick={() => setIsSettingsOpen(true)} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors" aria-label="Open settings">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-600 dark:text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                            </svg>
                        </button>
                    </div>
                </div>
            </header>

            <main className="flex-grow p-4 max-w-md mx-auto w-full flex flex-col">
                <div className="flex-grow flex flex-col">
                    {entries.length > 0 ? (
                        <div className="flex-grow bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-4 mb-4 overflow-hidden flex flex-col">
                           <div className="overflow-y-auto divide-y divide-gray-100 dark:divide-gray-700">
                             {entries.slice().reverse().map(entry => (
                                <HistoryItem key={entry.id} entry={entry} currencySymbol={currencySymbol} />
                             ))}
                           </div>
                        </div>
                    ) : (
                        <div className="flex-grow flex items-center justify-center text-center text-gray-500 dark:text-gray-400 mb-4">
                            <div>
                                <p className="text-lg font-medium">Welcome!</p>
                                <p className="text-sm">Add your first transaction below.</p>
                            </div>
                        </div>
                    )}
                </div>
                
                <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl p-4 sticky bottom-4 shadow-lg border border-gray-200 dark:border-gray-700">
                    <div className="relative">
                        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-2xl font-bold text-gray-400 dark:text-gray-500">{currencySymbol}</span>
                        <input
                            type="text"
                            inputMode="numeric"
                            value={amount}
                            onChange={handleAmountChange}
                            placeholder="0"
                            className="w-full bg-gray-100 border-2 border-gray-200 rounded-xl py-3 pl-12 pr-4 text-2xl font-bold text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition dark:bg-gray-700 dark:border-gray-600 dark:text-gray-100 dark:placeholder-gray-400"
                        />
                    </div>

                    {amount && (
                        <div className="mt-4 animate-fade-in">
                            <input
                                type="text"
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                                placeholder="Description (e.g., Salary, Groceries)"
                                className="w-full bg-gray-100 border-2 border-gray-200 rounded-xl py-3 px-4 text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition dark:bg-gray-700 dark:border-gray-600 dark:text-gray-100 dark:placeholder-gray-400"
                            />
                            <div className="mt-2 flex overflow-x-auto space-x-2 pb-2 -mx-4 px-4">
                                {suggestionList.map(s => (
                                    <button 
                                      key={s} 
                                      onClick={() => setDescription(s)}
                                      className="flex-shrink-0 px-4 py-1.5 bg-white border border-gray-300 rounded-full text-sm font-medium text-gray-700 hover:bg-gray-100 transition-colors dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-600"
                                    >
                                      {s}
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}
                    
                    {error && <p className="text-red-500 dark:text-red-400 text-sm mt-2 text-center">{error}</p>}

                    <div className="mt-4 grid grid-cols-2 gap-4">
                        <button 
                            onClick={() => handleAddEntry(true)}
                            className="flex items-center justify-center gap-2 py-3 bg-green-500 text-white font-bold rounded-xl shadow-md hover:bg-green-600 transition-transform transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                            disabled={!amount || !description}
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm.707-10.293a1 1 0 00-1.414-1.414l-3 3a1 1 0 001.414 1.414L9 9.414V13a1 1 0 102 0V9.414l1.293 1.293a1 1 0 001.414-1.414l-3-3z" clipRule="evenodd" /></svg>
                            <span>Income</span>
                        </button>
                        <button 
                            onClick={() => handleAddEntry(false)}
                            className="flex items-center justify-center gap-2 py-3 bg-red-500 text-white font-bold rounded-xl shadow-md hover:bg-red-600 transition-transform transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                            disabled={!amount || !description}
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm-.707-4.707a1 1 0 001.414 1.414l3-3a1 1 0 00-1.414-1.414L11 10.586V7a1 1 0 10-2 0v3.586L7.707 9.293a1 1 0 00-1.414 1.414l3 3z" clipRule="evenodd" /></svg>
                            <span>Expense</span>
                        </button>
                    </div>

                    <div className={`mt-6 text-center p-4 rounded-2xl transition-colors ${totalBalance >= 0 ? 'bg-green-100 text-green-800 dark:bg-green-900/60 dark:text-green-300' : 'bg-red-100 text-red-800 dark:bg-red-900/60 dark:text-red-300'}`}>
                        <p className="text-sm font-medium">Total Balance</p>
                        <p className="text-2xl font-bold">{currencySymbol} {totalBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                    </div>
                </div>
            </main>
            
            <SettingsModal 
                isOpen={isSettingsOpen} 
                onClose={() => setIsSettingsOpen(false)} 
                onSelectCurrency={handleSelectCurrency}
                selectedCurrency={selectedCurrency}
            />
            <style>{`
                @keyframes fade-in {
                    from { opacity: 0; transform: translateY(-10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in { animation: fade-in 0.3s ease-out forwards; }
                /* Custom scrollbar for suggestions */
                .overflow-x-auto::-webkit-scrollbar {
                    height: 4px;
                }
                .overflow-x-auto::-webkit-scrollbar-thumb {
                    background-color: #d1d5db;
                    border-radius: 20px;
                }
                .dark .overflow-x-auto::-webkit-scrollbar-thumb {
                    background-color: #4b5563;
                }
            `}</style>
        </div>
    );
}

export default App;
